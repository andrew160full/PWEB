import React from 'react'

function VendorHistory() {
  return (
    <div>VendorHistory</div>
  )
}

export default VendorHistory