import React from 'react'
import {Routes, Route} from 'react-router-dom'
import Login from './auth/Login'




export default function Body() {
    return (
        <section>
            
        </section>
    )
}
