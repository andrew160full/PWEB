export const omit = ["page", "sort", "limit"];
export const regex = /\b(gte|gt|lt|lte|regex)\b/g;
