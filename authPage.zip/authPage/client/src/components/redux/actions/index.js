const ACTIONS = {
    LOGIN: 'LOGIN',
}


export  default ACTIONS